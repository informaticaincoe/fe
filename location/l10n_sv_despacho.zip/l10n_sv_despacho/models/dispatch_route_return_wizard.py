from odoo import api, fields, models, _, Command
from odoo.exceptions import ValidationError


class DispatchRouteReturnWizard(models.TransientModel):
    _name = "dispatch.route.return.wizard"
    _description = "Wizard devolución por factura"

    reception_id = fields.Many2one("dispatch.route.reception", required=True)
    reception_line_id = fields.Many2one("dispatch.route.reception.line", required=True)
    move_id = fields.Many2one("account.move", string="Factura", required=True)

    notes = fields.Text(string="Observaciones")
    line_ids = fields.One2many("dispatch.route.return.wizard.line", "wizard_id", string="Productos")

    # HELPER QUE CARGA LOS PRODUCTOS
    def _load_invoice_products(self):
        self.ensure_one()
        if not self.move_id:
            self.line_ids = [(5,0,0)]
            return

        cmds = [(5, 0, 0)] #LIMPIAR TABLA

        # Importante: invoice_line_ids (no line_ids) para facturas
        lines = self.move_id.invoice_line_ids.filtered(lambda l: l.product_id and not l.display_type)

        for il in lines:
            uom = il.product_uom_id or il.product_id.uom_id
            qty = il.quantity or 0.0
            cmds.append((0, 0, {
                "select": False,
                "product_id": il.product_id.id,
                "uom_id": uom.id,
                "qty_invoiced": qty,
                "qty_return": 0.0,
                "reason": "other",
            }))

        self.line_ids = cmds

    @api.model
    def default_get(self, fields_list):
        res = super().default_get(fields_list)

        if "line_ids" in fields_list:
            move_id = res.get("move_id") or self.env.context.get("default_move_id")
            res["line_ids"] = self._get_invoice_products_commands(move_id)

        return res

    @api.model
    def _get_invoice_products_commands(self, move_id):
        if not move_id:
            return [Command.clear()]

        invoice = self.env["account.move"].browse(move_id).exists()
        if not invoice:
            return [Command.clear()]

        cmds = [Command.clear()]
        lines = invoice.invoice_line_ids.filtered(lambda l: l.product_id and not l.display_type)

        for il in lines:
            uom = il.product_uom_id or il.product_id.uom_id
            qty = il.quantity or 0.0
            cmds.append(Command.create({
                "select": False,
                "product_id": il.product_id.id,
                "uom_id": uom.id,
                "qty_invoiced": qty,
                "qty_return": 0.0,
                "reason": "other",
                "note": False,
            }))
        return cmds

    @api.model_create_multi
    def create(self, vals_list):
        wizards = super().create(vals_list)
        for wiz in wizards:
            if wiz.move_id and not wiz.line_ids:
                wiz.line_ids = wiz._get_invoice_products_commands(wiz.move_id.id)
        return wizards

    @api.onchange("move_id")
    def _onchange_move_id(self):
        for wiz in self:
            wiz._load_invoice_products()

    def action_save_return(self):
        self.ensure_one()

        selected = self.line_ids.filtered(lambda l: l.select and l.qty_return > 0)
        if not selected:
            raise ValidationError(_("Seleccione al menos un producto y coloque cantidad devuelta > 0."))

        # Validaciones
        for ln in selected:
            if ln.qty_return > ln.qty_invoiced:
                raise ValidationError(_("La cantidad devuelta no puede exceder la facturada (%s).") % ln.product_id.display_name)

        ret = self.env["dispatch.route.return"].create({
            "reception_id": self.reception_id.id,
            "move_id": self.move_id.id,
            "notes": self.notes,
            "line_ids": [(0, 0, {
                "product_id": ln.product_id.id,
                "uom_id": ln.uom_id.id,
                "qty_invoiced": ln.qty_invoiced,
                "qty_return": ln.qty_return,
                "reason": ln.reason,
                "note": ln.note,
            }) for ln in selected],
        })

        # Opcional: marcar en la línea de recepción que ya tiene devolución registrada
        self.reception_line_id.write({"has_return": True})

        return {"type": "ir.actions.act_window_close"}


class DispatchRouteReturnWizardLine(models.TransientModel):
    _name = "dispatch.route.return.wizard.line"
    _description = "Línea wizard devolución"

    wizard_id = fields.Many2one("dispatch.route.return.wizard", required=True, ondelete="cascade")
    select = fields.Boolean(string="Devolver", default=False)

    product_id = fields.Many2one(
        "product.product", string="Producto", required=True,
        domain=[("sale_ok", "=", True)],
    )
    uom_id = fields.Many2one("uom.uom", string="UdM", required=True)

    qty_invoiced = fields.Float(string="Cant. facturada", readonly=True)
    qty_return = fields.Float(string="Cant. devuelta", default=0.0)

    reason = fields.Selection(
        [
            ("damaged", "Avería"),
            ("wrong", "Producto equivocado"),
            ("expired", "Vencido"),
            ("customer_reject", "Rechazado por cliente"),
            ("other", "Otro"),
        ],
        string="Motivo",
        default="other",
        required=True,
    )
    note = fields.Char(string="Detalle")

    @api.onchange("product_id")
    def _onchange_product_id(self):
        for ln in self:
            if ln.product_id and not ln.uom_id:
                ln.uom_id = ln.product_id.uom_id.id
