# -*- coding: utf-8 -*-
from . import res_partner
from . import res_company
from . import ir_sequence
from . import account_journal
from . import account_catalogos
from  . import product_template
from . import accout_move_line
from . import account_move
from . import account_tax