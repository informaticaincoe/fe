# -*- coding: utf-8 -*-
from . import account_journal
from . import amount_to_text_sv
from . import account_move
from . import posicion_arancel
from . import product_template
from . import account_tax
from . import account_move_line
from . import sale_order
from . import res_partner
from . import sv_dte_retencion_recibida_1
